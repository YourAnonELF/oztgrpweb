const textElement = document.getElementById('text');
const originalText = "OZT COMPANY";
const newText = "Giriş Yap";

textElement.addEventListener('mouseenter', () => {
    textElement.textContent = newText;
});

textElement.addEventListener('mouseleave', () => {
    textElement.textContent = originalText;
});
